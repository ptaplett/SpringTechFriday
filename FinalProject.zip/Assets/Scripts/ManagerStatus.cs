﻿public enum ManagerStatus
// List of the different possible states
// Status property of other managers will envoke these states
{
	Shutdown,
	Initializing,
	Started
}